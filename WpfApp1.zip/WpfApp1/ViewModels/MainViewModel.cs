﻿using System.Windows;
namespace WpfApp1.ViewModels;
public class MainViewModel
{
    public MainViewModel() { }

}
