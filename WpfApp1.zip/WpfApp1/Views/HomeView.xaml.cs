﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Runtime.ConstrainedExecution;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using WpfApp1.Models;
using WpfApp1.ViewModels;

namespace WpfApp1.Views
{
    public partial class HomeView : Page, INotifyPropertyChanged
    {
        ObservableCollection<Comment> _comments = new ObservableCollection<Comment>();
        public ObservableCollection<Comment> Comments
        {
            get { return _comments; }
            set
            {
                _comments = value;
                OnPropertyChanged(nameof(Comments));
            }
        }
        public event PropertyChangedEventHandler PropertyChanged;
        protected virtual void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
        public HomeView()
        {
            InitializeComponent();
            DataContext = this;
        }
        private async void Button_ClickAsync(object sender, RoutedEventArgs e)
        {
            string link = textbox.Text.ToString();
          
            if (!File.Exists("../../../Resources/comments.json"))
            {
              
                HttpClient client = new HttpClient();
                List<Comment> comments = null;
                string response = await client.GetStringAsync(link);
                comments = JsonSerializer.Deserialize<List<Comment>>(response);
                File.WriteAllText("../../../Resources/comments.json", response);
            }
            else
            {
                getfromfile();
            }
        }
        public void getfromfile()
        {
            string jsonContent = File.ReadAllText("../../../Resources/" + "comments.json");
            var coms = JsonSerializer.Deserialize<List<Comment>>(jsonContent);
            foreach (var com in coms)
            {
                Comments.Add(com);
            }
        }

    }
}
